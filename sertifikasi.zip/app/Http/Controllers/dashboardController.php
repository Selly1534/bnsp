<?php

namespace App\Http\Controllers;

use App\Charts\MonthlyUsersChart;
use Illuminate\Http\Request;

class dashboardController extends Controller
{
    public function _invoke(MonthlyUsersChart $chart)
    {
        // $data['chart'] = $chart->build();
        return view('dashboard', ['chart' => $chart->build()]);
    }
}
