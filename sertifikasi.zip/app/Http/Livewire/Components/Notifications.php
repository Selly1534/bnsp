<?php

namespace App\Http\Livewire\Components;

use Livewire\Component;

class Notifications extends Component
{
    public function render()
    {
        return view('components.notifications');
    }
}
