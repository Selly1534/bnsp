<?php $__env->startSection('title', $title); ?>
<div>
  <div class="row mt-5">
    <div class="col-12 col-xl-8">
      <?php if($showSavedAlert): ?>
      <div class="alert alert-success" role="alert">
        Saved!
      </div>
      <?php endif; ?>
      <div class="card card-body mb-4 border-0 shadow">
        <form wire:submit.prevent="save">

          <div class="row">
            <div class="col-md-6 mb-3">
              <div>
                <label for="first_name">Nama Depan</label>
                <input wire:model="user.first_name" class="form-control" id="first_name" type="text" placeholder="Masukan nama depan" required>
              </div>
            </div>
            <div class="col-md-6 mb-3">
              <div>
                <label for="last_name">Nama Belakang</label>
                <input wire:model="user.last_name" class="form-control" id="last_name" type="text" placeholder="Masukan nama belakang">
              </div>
            </div>
          </div>

          <div class="row align-items-center">
            <div class="col-md-6 mb-3">
              <div class="form-group">
                <label for="email">Email</label>
                <input wire:model="user.email" class="form-control" id="email" type="email" placeholder="email.contoh@gmail.com">
              </div>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6 mb-3">
              <label for="gender">Gender</label>
              <select wire:model="user.gender" class="form-select mb-0" id="gender">
                <?php
                $arr = ['Pria', 'Wanita'];
                ?>
                <option value>Jenis Kelamin</option>
                <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['user.gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-9 mb-3">
              <div class="form-group">
                <label for="address">Alamat</label>
                <input wire:model="user.address" class="form-control" id="address" type="text" placeholder="Masukan alamat">
              </div>
              <?php $__errorArgs = ['user.address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-sm-3 mb-3">
              <div class="form-group">
                <label for="number">No Telepon</label>
                <input wire:model="user.number" class="form-control" id="number" type="tel" placeholder="Nomor telepon">
              </div>
              <?php $__errorArgs = ['user.number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mt-3">
            <button type="submit" class="btn btn-gray-800 animate-up-2 mt-2">Simpan
              All</button>
          </div>
        </form>
      </div>
    </div>

    <div class="col-12 col-xl-4">
      <div class="row">
        <div class="col-12 mb-4">
          <div class="card border-0 p-0 text-center shadow">
            <div wire:ignore.self class="profile-cover rounded-top" data-background="../assets/img/profile-cover.jpg"></div>
            <div class="card-body pb-5">
              <img class="avatar-xl rounded-circle mt-n7 mx-auto mb-4" src="https://ui-avatars.com/api/?background=random&name=<?php echo e($user->first_name
                    ? $user->full_name
                    : "
                                                                                                User Name"); ?>" alt="<?php echo e($user->first_name
                    ? $user->full_name
                    : "
                                                                                                User Name"); ?>">
              <h4 class="h3">
                <?php echo e($user->first_name ? $user->full_name : 'User Name'); ?>

              </h4>
              <?php if($user->is_admin): ?>
              <h5 class="fw-normal">System Admin</h5>
              <?php else: ?>
              <h5 class="fw-normal"><?php echo e($user->job->title); ?></h5>
              <p class="text-gray mb-4"><?php echo e($user->address); ?></p>
              <?php endif; ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\sertifikasi\resources\views/livewire/profile.blade.php ENDPATH**/ ?>