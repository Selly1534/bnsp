<div class="card card-body table-wrapper table-responsive border-0 shadow">
    <h2 class="text-center text-muted mb-3"><?php echo e(\Carbon\Carbon::today()->format("l, F d, Y")); ?></h2>
  <table class="table-hover table">
    <thead>
      <tr>
        <th class="border-gray-200">#</th>
        <th class="border-gray-200">Full Name</th>
        <th class="border-gray-200">Job</th>
        <th class="border-gray-200">Department</th>
        <th class="border-gray-200">Status</th>
        <th class="border-gray-200">Action</th>
      </tr>
    </thead>
    <tbody>

      <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td class="fw-bold"><?php echo e($loop->iteration); ?></td>
          <td><span class="fw-normal"><?php echo e($user->full_name); ?></span></td>
          <td><span class="fw-normal text-success"><?php echo e($user->job->title ?? 'Null'); ?></span></td>
          <td><span class="fw-normal text-info"><?php echo e($user->job->department->name ?? 'Null'); ?></span></td>
          <td><span class="fw-normal"><?php echo $user->attendance ? "<span class='badge bg-info'>" . $user->attendance->status . '</span>' : "<span class='text-danger'>Null</span>"; ?></span></td>
          <td class="inline-flex">
            <button style="font-size:0.8rem; padding:0.1 rem 0.2" class="btn me-3 btn-sm btn-warning" wire:click='attendance(<?php echo e($user->id); ?>,0)'>At Work</button>
            <button style="font-size:0.8rem; padding:0.1 rem 0.2" class="btn me-3 btn-sm btn-danger" wire:click='attendance(<?php echo e($user->id); ?>,1)'>Absent</button>
            <button style="font-size:0.8rem; padding:0.1 rem 0.2" class="btn me-3 btn-sm btn-gray-200" wire:click='attendance(<?php echo e($user->id); ?>,2)'>Late</button>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <?php endif; ?>



    </tbody>
  </table>
  <div class="card-footer mt-3 border-0 px-3">
    <?php echo e($users->links()); ?>

  </div>
</div>
<?php /**PATH C:\xampp\htdocs\sertifikasi\resources\views/livewire/attendances.blade.php ENDPATH**/ ?>