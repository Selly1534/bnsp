<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Favicons -->
  <link rel="apple-touch-icon" href="../../assets/img/favicon/apple-touch-icon.png" sizes="180x180">
  <link rel="icon" href="../../assets/img/favicon/favicon-32x32.png" sizes="32x32" type="image/png">
  <link rel="icon" href="../../assets/img/favicon/favicon-16x16.png" sizes="16x16" type="image/png">

  <link rel="mask-icon" href="../../assets/img/favicon/safari-pinned-tab.svg" color="#563d7c">
  <link rel="icon" href="../../assets/img/favicon/favicon.ico">
  <meta name="msapplication-config" content="../../assets/img/favicons/browserconfig.xml">
  <meta name="theme-color" content="#563d7c">
  <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">

  <!-- Apex Charts -->
  

    <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Datepicker -->
  
  

  <!-- Fontawesome -->
  <link type="text/css" href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
  
  <!-- Sweet Alert -->
  <link type="text/css" href="<?php echo e(asset('vendor/sweetalert2/sweetalert2.min.css.css')); ?>" rel="stylesheet">

  <!-- Notyf -->
  

  <!-- Volt CSS -->
  <link type="text/css" href="<?php echo e(asset('css/volt.css')); ?>" rel="stylesheet">
  <?php echo \Livewire\Livewire::styles(); ?>


  <title><?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent("title"); ?></title>
</head>

<body>

  
  <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <?php echo $__env->make('layouts.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main class="content">
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('top-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('l1951876080-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1951876080-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1951876080-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1951876080-0');
} else {
    $response = \Livewire\Livewire::mount('top-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1951876080-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo $__env->yieldContent("content"); ?>
  </main>
  <?php echo $__env->yieldContent("chart"); ?>
  <?php echo \Livewire\Livewire::scripts(); ?>


  <!-- Core -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>

  <!-- Vendor JS -->
  <script src="<?php echo e(asset('assets/js/on-screen.umd.min.js')); ?>"></script>
  
  <!-- Slider -->
  

  <!-- Smooth scroll -->
  <script src="<?php echo e(asset('assets/js/smooth-scroll.polyfills.min.js')); ?>"></script>

  <!-- Apex Charts -->
  

  <!-- Charts -->
  
  

  <!-- Datepicker -->
  

  <!-- Moment JS -->
  

  <!-- Notyf -->
  

  <!-- Simplebar -->
  

  <!-- Github buttons -->
  

  <!-- Volt JS -->
  <script src="<?php echo e(asset('assets/js/volt.js')); ?>"></script>

  
  <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>

  <?php echo $__env->yieldPushContent('scripts'); ?>
  
  <?php if(Session::has('message')): ?>
    <script>
      Swal.fire({
        timer: 2500,
        icon: "<?php echo e(Session::get('icon')); ?>",
        title: "<?php echo e(Session::get('title')); ?>",
        text: "<?php echo e(Session::get('message')); ?>",
      })
    </script>
  <?php endif; ?>

</body>

</html>


<?php /**PATH C:\xampp\htdocs\sertifikasi\resources\views/layouts/app.blade.php ENDPATH**/ ?>