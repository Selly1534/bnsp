<?php $__env->startSection("content"); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile', [])->html();
} elseif ($_instance->childHasBeenRendered('KG79uJn')) {
    $componentId = $_instance->getRenderedChildComponentId('KG79uJn');
    $componentTag = $_instance->getRenderedChildComponentTagName('KG79uJn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KG79uJn');
} else {
    $response = \Livewire\Livewire::mount('profile', []);
    $html = $response->html();
    $_instance->logRenderedChild('KG79uJn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sertifikasi\resources\views/profile.blade.php ENDPATH**/ ?>